module.exports = {
  async add(a, b) {
    return Promise.resolve(a + b);
  }
};
