const { sum } = require('../math');

test('should calculate the sum of two numbers', () => {
	
});
